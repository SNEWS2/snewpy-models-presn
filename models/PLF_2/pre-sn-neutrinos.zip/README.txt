README

Inlists and final models for the following paper:
https://ui.adsabs.harvard.edu/#abs/2015arXiv151102820P/abstract

Models and inlists came from this paper orignally, using MESA r7624:
http://adsabs.harvard.edu/abs/2016ApJS..227...22F

To run the different masses alter the initial_mass in inlist_cluster

Nameing convention:
15_nml_204_0p1.mod

Means:
15 initial mass in msun
nml no mass loss
204 204 isotopes in network
0p1 maximum cell size was 0.1msun

Model files are taken at core collapse additional times can be provided upon request to
rjfarmer@asu.edu
